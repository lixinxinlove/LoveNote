package com.love.lixinxin.lovenote.dialog;

import android.support.v4.app.DialogFragment;

/**
 * Created by lixinxin on 2018/3/7.
 * 基类
 */

public class BaseFragmentDialog extends DialogFragment{


}
